// ERole.java
package com.marketplace.emarketplacebackend.model; // or appropriate 'enums' package

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SELLER
}